import React, { useState, useEffect, useCallback } from 'react';
import { TrendTopic, FilterState, CartItem, GroundingSource } from './types';
import { fetchTrendingTopics } from './services/geminiService';
import Sidebar from './components/Sidebar';
import TrendCard from './components/TrendCard';
import SavedCart from './components/SavedCart';
import { ShoppingBag, Loader2, RefreshCw, Menu, ExternalLink } from 'lucide-react';
import { DEFAULT_FILTERS as CONST_DEFAULT_FILTERS } from './constants';

const App: React.FC = () => {
  const [trends, setTrends] = useState<TrendTopic[]>([]);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [filters, setFilters] = useState<FilterState>(CONST_DEFAULT_FILTERS);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const loadTrends = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { trends: data, sources: sourceData } = await fetchTrendingTopics(filters);
      setTrends(data);
      setSources(sourceData);
    } catch (err) {
      console.error(err);
      setError("Failed to fetch trends. Please try again later.");
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    loadTrends();
  }, [loadTrends]);

  const addToCart = (trend: TrendTopic) => {
    if (!cart.some(item => item.id === trend.id)) {
      setCart([...cart, { ...trend, savedAt: Date.now() }]);
    }
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 overflow-hidden">
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
            className="fixed inset-0 bg-slate-900/50 z-20 md:hidden backdrop-blur-sm"
            onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-30 transform transition-transform duration-300 md:relative md:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <Sidebar filters={filters} setFilters={setFilters} />
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Header */}
        <header className="h-16 border-b border-slate-200 bg-white/80 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <button 
                className="md:hidden text-slate-500 hover:text-slate-900"
                onClick={() => setIsMobileMenuOpen(true)}
            >
                <Menu size={24} />
            </button>
            <div>
                <h2 className="text-lg font-bold text-slate-900 hidden sm:block">
                    {filters.region === 'GLOBAL' ? 'Global' : filters.region} Trends
                </h2>
                <p className="text-xs text-slate-500 hidden sm:block">
                    Showing top results for {filters.category} • {filters.timeframe === '24h' ? 'Last 24 Hours' : filters.timeframe === '7d' ? 'Last 7 Days' : 'Last 30 Days'}
                </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             <button 
                onClick={loadTrends}
                disabled={loading}
                className="p-2 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-full transition-all disabled:opacity-50"
                title="Refresh Trends"
            >
                <RefreshCw size={20} className={loading ? 'animate-spin' : ''} />
            </button>
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all group"
            >
              <ShoppingBag size={20} className="group-hover:text-blue-600" />
              {cart.length > 0 && (
                <span className="absolute top-0 right-0 h-5 w-5 bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center rounded-full border-2 border-white shadow-sm">
                  {cart.length}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
            
            {/* Header for Mobile (since title is hidden in header on mobile) */}
            <div className="md:hidden mb-6">
                 <h2 className="text-2xl font-bold text-slate-900">
                    {filters.region === 'GLOBAL' ? 'Global' : filters.region} Trends
                </h2>
                <p className="text-sm text-slate-500">
                    {filters.category} • {filters.timeframe} • {filters.platform === 'All' ? 'Google & YouTube' : filters.platform}
                </p>
            </div>

            {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3, 4, 5, 6].map(i => (
                        <div key={i} className="bg-white border border-slate-200 rounded-xl p-6 h-full flex flex-col relative overflow-hidden animate-pulse shadow-sm">
                            <div className="flex justify-between items-start mb-4">
                                <div className="flex-1 pr-4">
                                    <div className="flex items-center gap-2 mb-3">
                                        <div className="h-5 w-20 bg-slate-200 rounded-full"></div>
                                        <div className="h-4 w-4 bg-slate-200 rounded-full"></div>
                                    </div>
                                    <div className="h-7 w-3/4 bg-slate-200 rounded mb-2"></div>
                                    <div className="h-7 w-1/2 bg-slate-200 rounded"></div>
                                </div>
                                <div className="h-10 w-12 bg-slate-200 rounded-lg"></div>
                            </div>
                            
                            <div className="mb-6 space-y-3 flex-grow">
                                <div className="h-4 w-full bg-slate-200 rounded"></div>
                                <div className="h-4 w-full bg-slate-200 rounded"></div>
                                <div className="h-4 w-5/6 bg-slate-200 rounded"></div>
                            </div>

                            <div className="mt-auto space-y-3">
                                <div className="h-4 w-28 bg-slate-200 rounded mx-auto"></div>
                                <div className="h-11 w-full bg-slate-200 rounded-lg"></div>
                                <div className="h-11 w-full bg-slate-200 rounded-lg"></div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : error ? (
                <div className="flex flex-col items-center justify-center h-full text-slate-500">
                    <p className="text-lg mb-4">{error}</p>
                    <button 
                        onClick={loadTrends}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 font-medium"
                    >
                        Try Again
                    </button>
                </div>
            ) : trends.length === 0 ? (
                <div className="text-center text-slate-500 mt-20">
                    <p>No trends found for these filters.</p>
                </div>
            ) : (
                <>
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                        {trends.map((trend, index) => (
                            <TrendCard 
                                key={trend.id} 
                                trend={trend} 
                                rank={index + 1}
                                onAddToCart={addToCart}
                                isInCart={cart.some(item => item.id === trend.id)}
                            />
                        ))}
                    </div>

                    {/* Sources Section */}
                    {sources.length > 0 && (
                        <div className="mt-8 pt-6 border-t border-slate-200">
                            <h4 className="text-sm font-semibold text-slate-500 mb-3 flex items-center gap-2">
                                <ExternalLink size={14} /> Sources
                            </h4>
                            <div className="flex flex-wrap gap-3">
                                {sources.map((source, index) => (
                                    <a 
                                        key={index}
                                        href={source.uri}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-xs text-blue-600 hover:text-blue-800 bg-white px-2 py-1 rounded border border-slate-200 hover:border-blue-400 transition-colors truncate max-w-[200px]"
                                        title={source.title}
                                    >
                                        {source.title}
                                    </a>
                                ))}
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>

        {/* Cart Drawer */}
        <SavedCart 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          cart={cart}
          onRemove={removeFromCart}
        />
      </main>
    </div>
  );
};

export default App;