import { GoogleGenAI, Type } from "@google/genai";
import { TrendTopic, FilterState, GroundingSource } from "../types";
import { REGIONS, MOCK_TRENDS } from "../constants";
import { fetchYouTubeTrends } from "./youtubeService";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper to clean JSON string from Markdown code blocks if any remain
const cleanJsonString = (text: string): string => {
  let clean = text.trim();
  if (clean.startsWith('```json')) {
    clean = clean.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (clean.startsWith('```')) {
    clean = clean.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  return clean;
};

export const fetchTrendingTopics = async (filters: FilterState): Promise<{ trends: TrendTopic[], sources: GroundingSource[] }> => {
  const timeframeText = {
      '24h': 'past 24 hours',
      '7d': 'past 7 days',
      '30d': 'past 30 days'
  }[filters.timeframe] || 'past 24 hours';

  const regionName = REGIONS.find(r => r.id === filters.region)?.name || filters.region;

  // Fetch YouTube Context if applicable
  let youtubeContext = "";
  if (filters.platform !== 'Google') {
    try {
        const ytVideos = await fetchYouTubeTrends(filters.region, filters.category);
        if (ytVideos.length > 0) {
            youtubeContext = `
    REAL-TIME YOUTUBE DATA (PRIORITY: Incorporate these exact trending videos into the results if they match the category):
    ${ytVideos.join('\n')}
            `;
        }
    } catch (e) {
        console.warn("Failed to load YouTube context", e);
    }
  }

  const systemInstruction = `
    You are a specialized trend intelligence agent. Your task is to curate real-time trending topics.
    
    CRITICAL RULES:
    1. Output ONLY a valid JSON object. 
    2. Do NOT include any conversational preamble, explanation, or markdown backticks unless forced by the environment.
    3. Respect the category filter strictly.
    4. Use the googleSearch tool to find actual real-time data for ${regionName}.
    5. Prioritize the provided YouTube Data when the platform includes YouTube.
  `;

  const prompt = `
    Find the top 15 trending topics for ${regionName} in the ${timeframeText}.
    Filter by Category: "${filters.category}"
    Platform focus: ${filters.platform === 'All' ? 'Google Search and YouTube' : filters.platform}
    
    ${youtubeContext}
    
    Ensure each trend has:
    - A specific topic name
    - A contextual description
    - An interest score (0-100)
    - Estimated volume (e.g., "500K+")
    - A list of related entities (people, companies, brands)
    - 3 related keywords with their own scores
    - A 7-day history array of integers (representing popularity score 0-100)
  `;

  const makeRequest = async (retries = 2, delay = 2000): Promise<{ trends: TrendTopic[], sources: GroundingSource[] }> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: {
              systemInstruction,
              tools: [{ googleSearch: {} }],
              temperature: 0.2,
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  trends: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.STRING },
                        topic: { type: Type.STRING },
                        description: { type: Type.STRING },
                        score: { type: Type.NUMBER },
                        volume: { type: Type.STRING },
                        platform: { type: Type.STRING, enum: ["Google", "YouTube", "Both"] },
                        category: { type: Type.STRING },
                        sourceUrl: { type: Type.STRING },
                        entities: { 
                          type: Type.ARRAY,
                          items: { type: Type.STRING }
                        },
                        relatedTopics: {
                          type: Type.ARRAY,
                          items: {
                            type: Type.OBJECT,
                            properties: {
                              topic: { type: Type.STRING },
                              score: { type: Type.NUMBER }
                            },
                            required: ["topic", "score"]
                          }
                        },
                        history: {
                          type: Type.ARRAY,
                          items: { type: Type.INTEGER }
                        }
                      },
                      required: ["id", "topic", "description", "score", "volume", "platform", "category", "entities", "relatedTopics", "history"]
                    }
                  }
                },
                required: ["trends"]
              },
              thinkingConfig: { thinkingBudget: 4000 }
            },
        });

        const text = response.text || '';
        const cleanedJson = cleanJsonString(text);
        
        let trends: TrendTopic[] = [];
        try {
          const parsed = JSON.parse(cleanedJson);
          if (parsed && Array.isArray(parsed.trends)) {
            trends = parsed.trends;
          }
        } catch (parseError) {
          console.error("JSON Parse Error on cleaned text:", cleanedJson);
          throw parseError; // Trigger retry
        }
    
        const sources: GroundingSource[] = [];
        if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
            response.candidates[0].groundingMetadata.groundingChunks.forEach((chunk: any) => {
                if (chunk.web) {
                    sources.push({
                        title: chunk.web.title || 'Source',
                        uri: chunk.web.uri
                    });
                }
            });
        }
    
        return { trends, sources };
    } catch (error) {
        if (retries > 0) {
            console.warn(`Gemini Request failed. Retrying... (${retries} left)`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return makeRequest(retries - 1, delay * 2);
        } else {
            console.error("Gemini API critically failed after retries. Using mock data.");
            return { trends: MOCK_TRENDS, sources: [] };
        }
    }
  };

  return makeRequest();
};