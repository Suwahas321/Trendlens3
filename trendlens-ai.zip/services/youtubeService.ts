
const API_KEY = 'AIzaSyBwvvWG5Xqq_sb_d8vQ-VqYkQWooCt_yqc';

// YouTube Video Category IDs mapping
const CATEGORY_IDS: Record<string, string> = {
  'News': '25',
  'Political': '25',
  'AI': '28', // Science & Technology
  'Crypto': '28',
  'Technology': '28',
  'Entertainment': '24',
  'Business': '25', // News & Politics fallback
  'Health': '26', // Howto & Style
  'Sports': '17',
  'Science': '28',
  'Gaming': '20',
  'Fashion': '26',
};

export async function fetchYouTubeTrends(regionCode: string, category: string): Promise<string[]> {
  try {
    // Default to US if Global, as YouTube API requires a region code for mostPopular chart usually
    const region = regionCode === 'GLOBAL' ? 'US' : regionCode;
    const catId = CATEGORY_IDS[category];
    
    let url = `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&chart=mostPopular&regionCode=${region}&maxResults=15&key=${API_KEY}`;
    
    if (catId) {
      url += `&videoCategoryId=${catId}`;
    }

    const res = await fetch(url);
    if (!res.ok) {
        console.warn('YouTube API fetch failed:', res.statusText);
        return [];
    }
    
    const data = await res.json();
    if (!data.items) return [];

    return data.items.map((item: any) => 
      `Video: "${item.snippet.title}" by ${item.snippet.channelTitle} (${Number(item.statistics.viewCount).toLocaleString()} views)`
    );
  } catch (error) {
    console.warn('Error fetching YouTube trends:', error);
    return [];
  }
}
