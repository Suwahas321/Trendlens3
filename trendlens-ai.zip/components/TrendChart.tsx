import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendDataPoint } from '../types';

interface TrendChartProps {
  data: TrendDataPoint[];
  color?: string;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const dataPoint = payload[0].payload as TrendDataPoint;
    const color = payload[0].stroke;
    
    return (
      <div className="bg-white border border-slate-200 rounded-lg shadow-xl p-3 min-w-[120px]">
        <p className="text-[11px] text-slate-500 font-medium mb-1.5 border-b border-slate-100 pb-1.5">
          {dataPoint.date}
        </p>
        <div className="flex items-center gap-2">
            <span 
              className="w-2 h-2 rounded-full shadow-[0_0_8px_currentColor]" 
              style={{ backgroundColor: color, color: color }}
            ></span>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Trend Score</span>
              <span className="text-sm font-bold text-slate-900 leading-none">{payload[0].value}</span>
            </div>
        </div>
      </div>
    );
  }
  return null;
};

const TrendChart: React.FC<TrendChartProps> = ({ data, color = "#2563eb" }) => {
  return (
    <div className="h-32 w-full mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{
            top: 5,
            right: 5,
            left: -20,
            bottom: 0,
          }}
        >
          <defs>
            <linearGradient id={`colorGradient-${color}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.3} />
              <stop offset="95%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis 
            dataKey="day" 
            tick={{ fontSize: 10, fill: '#64748b' }} 
            tickLine={false}
            axisLine={false}
            interval="preserveStartEnd"
            padding={{ left: 10, right: 10 }}
          />
          <YAxis hide domain={[0, 100]} />
          <Tooltip 
            content={<CustomTooltip />}
            cursor={{ stroke: '#cbd5e1', strokeWidth: 1, strokeDasharray: '4 4' }}
          />
          <Area 
            type="monotone" 
            dataKey="value" 
            stroke={color} 
            fillOpacity={1} 
            fill={`url(#colorGradient-${color})`} 
            strokeWidth={2}
            activeDot={{ 
              r: 4, 
              stroke: '#fff', 
              strokeWidth: 2, 
              fill: color,
              className: "animate-pulse shadow-md" 
            }}
            animationDuration={1500}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TrendChart;