import React, { useState } from 'react';
import { FilterState } from '../types';
import { REGIONS, CATEGORIES, TIMEFRAMES } from '../constants';
import { LayoutDashboard, Globe, Tag, Youtube, Search, Layers, ChevronDown, ChevronRight, X, Clock, Zap } from 'lucide-react';

interface SidebarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  className?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ filters, setFilters, className = '' }) => {
  const [isRegionExpanded, setIsRegionExpanded] = useState(true);
  const [regionSearch, setRegionSearch] = useState('');
  
  const handleFilterChange = (key: keyof FilterState, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const selectedRegion = REGIONS.find(r => r.id === filters.region);

  const filteredRegions = REGIONS.filter(region => 
    region.name.toLowerCase().includes(regionSearch.toLowerCase())
  );

  return (
    <aside className={`bg-white border-r border-slate-200 w-64 flex-shrink-0 flex flex-col h-screen sticky top-0 ${className}`}>
      <div className="p-6">
        <h1 className="text-2xl font-black bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent flex items-center gap-3">
            <img 
              src="https://iili.io/fpXNrg9.png" 
              alt="TrendLens Logo" 
              className="w-8 h-8 rounded-lg shadow-sm object-contain" 
            />
            TrendLens
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-2 space-y-8 custom-scrollbar">
        
        {/* Region Section */}
        <div>
          <button 
            onClick={() => setIsRegionExpanded(!isRegionExpanded)}
            className="w-full flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 hover:text-slate-800 transition-colors group focus:outline-none"
          >
            <div className="flex items-center gap-2">
                <Globe size={14} className="text-slate-400 group-hover:text-slate-600" /> Region
            </div>
            {isRegionExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </button>
          
          {isRegionExpanded ? (
             <div className="space-y-1 animate-in slide-in-from-top-1 duration-200">
                {/* Search Input */}
                <div className="relative mb-3 px-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                    <input
                        type="text"
                        placeholder="Search country..."
                        value={regionSearch}
                        onChange={(e) => setRegionSearch(e.target.value)}
                        className="w-full pl-8 pr-7 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-slate-700 placeholder:text-slate-400 transition-all"
                    />
                    {regionSearch && (
                        <button 
                            onClick={() => setRegionSearch('')}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                        >
                            <X size={12} />
                        </button>
                    )}
                </div>

                <div className="max-h-[240px] overflow-y-auto pr-1 space-y-1 custom-scrollbar">
                    {filteredRegions.length > 0 ? (
                        filteredRegions.map(region => (
                        <button
                            key={region.id}
                            onClick={() => handleFilterChange('region', region.id)}
                            className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                            filters.region === region.id 
                                ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
                            }`}
                        >
                            <span className="text-lg leading-none flex-shrink-0">{region.flag}</span>
                            <span className="truncate">{region.name}</span>
                        </button>
                        ))
                    ) : (
                        <div className="px-3 py-2 text-xs text-slate-500 italic text-center">
                            No regions found
                        </div>
                    )}
                </div>
            </div>
          ) : (
             /* Collapsed State: Show only selected region */
             selectedRegion && (
                <button
                    onClick={() => setIsRegionExpanded(true)}
                    className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-2"
                >
                    <span className="text-lg leading-none">{selectedRegion.flag}</span>
                    <span className="truncate">{selectedRegion.name}</span>
                </button>
             )
          )}
        </div>

        {/* Timeframe Section */}
        <div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Clock size={14} /> Time Range
          </h3>
          <div className="grid grid-cols-1 gap-1">
             {TIMEFRAMES.map((tf) => (
                <button
                  key={tf.id}
                  onClick={() => handleFilterChange('timeframe', tf.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filters.timeframe === tf.id 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
                  }`}
                >
                  {tf.label}
                </button>
             ))}
          </div>
        </div>

        {/* Platform Section */}
        <div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Layers size={14} /> Platform
          </h3>
          <div className="grid grid-cols-1 gap-1">
             <button
                onClick={() => handleFilterChange('platform', 'All')}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filters.platform === 'All' 
                    ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
                }`}
              >
                <LayoutDashboard size={14} /> All Platforms
              </button>
              <button
                onClick={() => handleFilterChange('platform', 'Google')}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filters.platform === 'Google' 
                    ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
                }`}
              >
                <Search size={14} /> Google Search
              </button>
              <button
                onClick={() => handleFilterChange('platform', 'YouTube')}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filters.platform === 'YouTube' 
                    ? 'bg-red-50 text-red-700 border-red-200' 
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
                }`}
              >
                <Youtube size={14} /> YouTube
              </button>
          </div>
        </div>

        {/* Categories Section */}
        <div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Tag size={14} /> Categories
          </h3>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => handleFilterChange('category', cat)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                  filters.category === cat
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <div className="p-4 border-t border-slate-200">
        <div className="bg-slate-50 rounded-lg p-3 text-[10px] text-slate-500 border border-slate-100 flex items-center gap-2">
            <Zap size={12} className="text-blue-500 fill-blue-500" />
            <p className="font-medium uppercase tracking-tighter">Gemini 3 Flash Intelligence Active</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;