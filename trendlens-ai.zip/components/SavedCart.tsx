import React from 'react';
import { CartItem } from '../types';
import { X, Trash2, Download } from 'lucide-react';

interface SavedCartProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onRemove: (id: string) => void;
}

const SavedCart: React.FC<SavedCartProps> = ({ isOpen, onClose, cart, onRemove }) => {
  const exportCart = () => {
    const dataStr = JSON.stringify(cart, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'my-trends.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 transition-opacity"
          onClick={onClose}
        />
      )}
      
      {/* Drawer */}
      <div className={`fixed top-0 right-0 h-full w-full sm:w-96 bg-white border-l border-slate-200 z-50 transform transition-transform duration-300 ease-in-out shadow-2xl ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-6 h-full flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <span className="bg-blue-600 w-2 h-6 rounded-sm"></span>
              Trending Cart
              <span className="text-sm font-normal text-slate-500 ml-2">({cart.length})</span>
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-900 transition-colors">
              <X size={24} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center text-slate-500 mt-20">
                <p>No trends saved yet.</p>
                <p className="text-sm mt-2">Add topics from the dashboard to track them here.</p>
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.id} className="bg-slate-50 rounded-lg p-4 border border-slate-200 flex flex-col gap-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold text-slate-900">{item.topic}</h4>
                      <span className="text-xs text-slate-500">{item.category} • Score: {item.score}</span>
                    </div>
                    <button 
                      onClick={() => onRemove(item.id)}
                      className="text-slate-400 hover:text-red-500 transition-colors p-1"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div className="h-1 bg-slate-200 rounded-full mt-2 overflow-hidden">
                    <div 
                        className="h-full bg-blue-500" 
                        style={{ width: `${item.score}%` }}
                    ></div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="pt-6 mt-4 border-t border-slate-100">
            <button
              onClick={exportCart}
              disabled={cart.length === 0}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-slate-900/10"
            >
              <Download size={18} />
              Export Data
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default SavedCart;