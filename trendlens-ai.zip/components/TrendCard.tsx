import React, { useState, useMemo } from 'react';
import { TrendTopic, TrendDataPoint } from '../types';
import { Plus, Youtube, Search, Check, TrendingUp, ArrowRight, ChevronDown, ChevronUp, Users, Network, Activity, Eye, Flame } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, LineChart, Line } from 'recharts';
import TrendChart from './TrendChart';

interface TrendCardProps {
  trend: TrendTopic;
  rank: number;
  onAddToCart: (trend: TrendTopic) => void;
  isInCart: boolean;
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0].payload;
      const scoreColor = payload[0].fill;
      return (
        <div className="bg-white border border-slate-200 rounded-lg shadow-xl p-2 z-50">
          <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold mb-1">{dataPoint.topic}</p>
          <div className="flex items-center gap-2">
              <div 
                className="h-2 w-2 rounded-full" 
                style={{ backgroundColor: scoreColor }}
              ></div>
              <span className="text-xs font-bold text-slate-900">Score: {dataPoint.score}</span>
          </div>
        </div>
      );
    }
    return null;
  };

const TrendCard: React.FC<TrendCardProps> = ({ trend, rank, onAddToCart, isInCart }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Helper to interpolate color based on score (Blue -> Purple -> Red)
  const getGradientColor = (value: number) => {
    // Clamp value 0-100
    const score = Math.min(Math.max(value, 0), 100);
    
    // 0 -> Blue-500 (#3b82f6) [59, 130, 246]
    // 50 -> Violet-500 (#8b5cf6) [139, 92, 246]
    // 100 -> Red-500 (#ef4444) [239, 68, 68]
    
    let r, g, b;
    if (score < 50) {
        // Blue to Violet
        const ratio = score / 50;
        r = Math.round(59 + (139 - 59) * ratio);
        g = Math.round(130 + (92 - 130) * ratio);
        b = Math.round(246 + (246 - 246) * ratio);
    } else {
        // Violet to Red
        const ratio = (score - 50) / 50;
        r = Math.round(139 + (239 - 139) * ratio);
        g = Math.round(92 + (68 - 92) * ratio);
        b = Math.round(246 + (68 - 246) * ratio);
    }
    return `rgb(${r}, ${g}, ${b})`;
  };

  // Main chart color
  const chartColor = getGradientColor(trend.score);
  
  // Determine the primary link
  const sourceLink = trend.sourceUrl || `https://www.google.com/search?q=${encodeURIComponent(trend.topic)}`;

  // Generate history data for the chart
  const trendHistory = useMemo(() => {
    const today = new Date();
    
    // Use real history from API if available and complete
    if (trend.history && trend.history.length >= 7) {
        // We take the last 7 items just in case
        const recentHistory = trend.history.slice(-7);
        return recentHistory.map((val, index) => {
             // index 0 is 6 days ago, index 6 is today
             const date = new Date(today);
             date.setDate(date.getDate() - (6 - index));
             return {
                 day: date.toLocaleDateString('en-US', { weekday: 'short' }),
                 date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
                 value: Math.min(Math.max(val, 0), 100) // Clamp
             };
        });
    }

    // Fallback: Generate simulation if no history provided
    const data: TrendDataPoint[] = [];
    for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        
        let value;
        if (i === 0) {
            value = trend.score;
        } else {
            // Simulate a rising trend curve with some random variation
            const trendDrop = i * 4; 
            const variation = (Math.random() * 10) - 5;
            value = Math.max(10, Math.min(99, trend.score - trendDrop + variation));
        }

        data.push({
            day: date.toLocaleDateString('en-US', { weekday: 'short' }),
            date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            value: Math.round(value)
        });
    }
    return data;
  }, [trend.score, trend.history]);

  const RankBadge = () => {
    if (rank <= 3) {
        // Define styles for Gold, Silver, Bronze
        let badgeStyle = '';
        let iconStyle = '';
        
        if (rank === 1) { // Gold
            badgeStyle = 'bg-yellow-50 text-yellow-700 border-yellow-200';
            iconStyle = 'text-yellow-500 fill-yellow-500';
        } else if (rank === 2) { // Silver
            badgeStyle = 'bg-slate-100 text-slate-700 border-slate-200';
            iconStyle = 'text-slate-400 fill-slate-400';
        } else { // Bronze
            badgeStyle = 'bg-orange-50 text-orange-800 border-orange-200';
            iconStyle = 'text-orange-500 fill-orange-500';
        }

        return (
            <div className={`flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-full border shadow-sm ${badgeStyle}`}>
                <Flame size={12} className={iconStyle} />
                #{rank}
            </div>
        );
    }
    
    // Default Rank Badge
    return (
        <div className="flex items-center gap-1 text-xs font-bold text-slate-500 bg-white px-2 py-0.5 rounded-full border border-slate-200">
            #{rank}
        </div>
    );
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 transition-all duration-300 hover:shadow-xl hover:shadow-blue-900/5 hover:border-blue-300 group flex flex-col h-full relative overflow-hidden">
      
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1 pr-4">
            <div className="flex flex-wrap items-center gap-2 mb-2">
                <RankBadge />
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 uppercase tracking-wider border border-slate-200">
                    {trend.category}
                </span>
                {trend.volume && (
                    <div className="flex items-center gap-1 text-xs font-bold text-slate-600 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-200" title="Estimated Search/View Volume">
                        <Eye size={12} className="text-slate-400" />
                        {trend.volume}
                    </div>
                )}
                <div className="flex items-center gap-1 ml-1">
                    {trend.platform === 'YouTube' && <Youtube size={14} className="text-red-600" />}
                    {trend.platform === 'Google' && <Search size={14} className="text-blue-600" />}
                    {trend.platform === 'Both' && (
                        <div className="flex gap-1">
                            <Search size={14} className="text-blue-600" />
                            <Youtube size={14} className="text-red-600" />
                        </div>
                    )}
                </div>
            </div>
            <h3 className="text-xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-tight">
                {trend.topic}
            </h3>
        </div>
        <div className="flex flex-col items-end flex-shrink-0">
            <div className="flex items-center gap-1 bg-slate-50 px-2 py-1 rounded-lg border border-slate-100 mb-1">
                <TrendingUp size={16} style={{ color: chartColor }} />
                <span className="text-xl font-black" style={{ color: chartColor }}>{trend.score}</span>
            </div>
            <div className="h-8 w-20" title="7-Day Interest Trend">
                 <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trendHistory}>
                        <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke={chartColor} 
                            strokeWidth={2} 
                            dot={false}
                            isAnimationActive={false}
                        />
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>
      
      {/* Description Section - Always Visible */}
      <div className="mb-4 flex-grow">
        <p className="text-sm text-slate-600 leading-relaxed line-clamp-3">
            {trend.description}
        </p>
      </div>

      {/* Expanded Content Section */}
      {isExpanded && (
        <div className="mb-4 space-y-4 animate-in slide-in-from-top-2 duration-300">
             
             {/* Key Entities */}
             {trend.entities && trend.entities.length > 0 && (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                        <Users size={12} /> Key Entities & People
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                        {trend.entities.map((entity, index) => (
                            <span 
                                key={index} 
                                className="px-2 py-1 bg-white text-slate-700 text-xs font-medium border border-slate-200 rounded shadow-sm"
                            >
                                {entity}
                            </span>
                        ))}
                    </div>
                </div>
            )}

            {/* 7-Day Trend Chart - Detailed View */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                    <Activity size={12} /> 7-Day Interest Trend
                </h4>
                <TrendChart data={trendHistory} color={chartColor} />
            </div>

            {/* Related Trends Chart */}
            {trend.relatedTopics && trend.relatedTopics.length > 0 && (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                    <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                        <Network size={12} /> Related Trends
                    </h4>
                    <div className="h-40 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                        <BarChart 
                            data={trend.relatedTopics} 
                            layout="vertical" 
                            margin={{ top: 0, right: 30, left: 0, bottom: 0 }}
                        >
                            <XAxis type="number" hide domain={[0, 100]} />
                            <YAxis 
                                dataKey="topic" 
                                type="category" 
                                width={80} 
                                tick={{fontSize: 10, fill: '#64748b'}} 
                                interval={0} 
                            />
                            <Tooltip cursor={{fill: 'rgba(0,0,0,0.03)'}} content={<CustomTooltip />} />
                            <Bar dataKey="score" radius={[0, 4, 4, 0]} barSize={16}>
                                {trend.relatedTopics.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={getGradientColor(entry.score)} />
                                ))}
                            </Bar>
                        </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            )}
        </div>
      )}

      {/* Action Area */}
      <div className="mt-auto space-y-3">
          
          {/* Expand Toggle */}
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-full flex items-center justify-center gap-1 text-xs font-medium text-slate-500 hover:text-blue-600 py-1 transition-colors"
          >
            {isExpanded ? (
                <>Show Less <ChevronUp size={14} /></>
            ) : (
                <>View Details & Analysis <ChevronDown size={14} /></>
            )}
          </button>

          {/* Source Link */}
          <a 
            href={sourceLink} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center justify-between w-full p-3 rounded-lg bg-blue-50 border border-blue-100 hover:bg-blue-100/80 hover:border-blue-200 transition-all group/link"
          >
              <span className="text-sm font-medium text-blue-700 flex items-center gap-2">
                 Read Source Material
              </span>
              <ArrowRight size={16} className="text-blue-600 group-hover/link:text-blue-700 group-hover/link:translate-x-1 transition-transform" />
          </a>

          {/* Save Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(trend);
            }}
            disabled={isInCart}
            className={`w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 ${
              isInCart
                ? 'bg-green-100 text-green-700 cursor-default border border-green-200'
                : 'bg-slate-900 hover:bg-slate-800 text-white shadow-lg shadow-slate-900/10'
            }`}
          >
            {isInCart ? (
              <>
                <Check size={16} />
                Saved to Cart
              </>
            ) : (
              <>
                <Plus size={16} />
                Save Trend
              </>
            )}
          </button>
      </div>
    </div>
  );
};

export default TrendCard;