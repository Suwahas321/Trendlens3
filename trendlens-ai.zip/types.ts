export interface TrendDataPoint {
  day: string;
  date: string; // Formatted date string (e.g., "July 26, 2024")
  value: number;
}

export interface RelatedTopic {
  topic: string;
  score: number;
}

export interface TrendTopic {
  id: string;
  topic: string;
  description: string;
  score: number; // 0 to 100
  volume: string; // e.g. "100K+", "2M"
  platform: 'Google' | 'YouTube' | 'Both';
  category: string;
  sourceUrl?: string; // Specific source link
  entities: string[]; // Key people, companies, or concepts mentioned
  relatedTopics: RelatedTopic[];
  history?: number[]; // Array of 7 integers (0-100) representing last 7 days interest
}

export interface FilterState {
  region: string;
  category: string;
  platform: 'All' | 'Google' | 'YouTube';
  timeframe: '24h' | '7d' | '30d';
}

export interface CartItem extends TrendTopic {
  savedAt: number;
}

export interface GroundingSource {
  title: string;
  uri: string;
}